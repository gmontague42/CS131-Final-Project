#ifndef DATA_H_INCLUDED
#define DATA_H_INCLUDED
#define FILENAME "library.txt"
#include <string.h>
#include "library.h"
//function prototypes
int loadLibrary(library *lib);
void saveLibrary(library *lib);

#endif // DATA_H_INCLUDED
