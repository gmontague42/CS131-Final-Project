#include <stdio.h>
#include <string.h>
#include "Library.h"
/**************************************************************
 * Function: getBook
 * Description:  This function gets the value of the books and
 *               its details to return to main
 * Input: library *lib - main struct that holds all information
 *        int index - holds the number book that the user wants
 *                    to get
 **************************************************************/
book getBook(library *lib, int index)
{
    //declare variables
    book b;
    index--;
    //gets book user wants depending on input
    strcpy(b.title, lib->inventory[index].title);
    strcpy(b.author, lib->inventory[index].author);
    b.pubYear = lib->inventory[index].pubYear;
    return b;
}
/**************************************************************
 * Function: removeBook
 * Description:  This function removes the book that the user
 *               doesn't wish to have anymore
 * Input: library *lib - main struct that holds all information
 *        int index - holds the number book that the user wants
 *                    to delete
 **************************************************************/
void removeBook(library *lib, int index)
{
    index--;
    //removes book user wants by copying the values of next book
    //into book chosen by user
    for (int i = index; i < lib->bookCount; i++)
    {
        printf("%s\n%s\n ",lib->inventory[i].title, lib->inventory[i+1].title);
        strcpy(lib->inventory[i].title, lib->inventory[i+1].title);
        strcpy(lib->inventory[i].author, lib->inventory[i+1].author);
        lib->inventory[i].pubYear = lib->inventory[i+1].pubYear;
    }
    //subtracts book count to show book has been removed
    lib->bookCount--;
}
