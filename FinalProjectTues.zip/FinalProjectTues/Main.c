/***************************************************************
 * Project: Final Project
 * File: Main.c, Library.c, Library.h, Data.c, Data.h
 * Authors: Danny Peck, Vitaliy Karpinskiy, and Gwen Montague
 * Date: 12/8/2020
 * Description: This application allows user to create their own
 *              library, add books, edit books, remove books,
 *              view list of books, and view book details.
 ***************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "Library.h"
#include "Data.h"
/**************************************************************
 * Function: main
 * Description: This program allows a user to create their own
 *              library, add books, edit books, remove books,
 *              view list of books, and view book details.
 **************************************************************/
int main()
{
    char buf[MAX_SIZE];
    bool running = true;
    library* lib = malloc(sizeof(library));
    book bk;
    int input;
    int num; // number of items read (for scanf number validation)
    char term; // terminator character (for scanf number validation)
    // Display title of app the first time it runs
    printf("%s", "Library Simulator 2021\n");
    // If library does not exist, start a new library
    if (!loadLibrary(lib))
    {
        buf[0] = '\0';
        do
        {
            printf("%s", "What is the name of your library?\n");
            scanf("%49[^\n]s", buf);
            while (getchar() != '\n');
        }
        while (strlen(buf) <= 0 );
        strcpy(lib->name, buf);
        lib->bookCount = 0;
    }
    // Main program loop
    while (running)
    {
        printf("\nLibrary Name: %s\n\n", lib->name);
        printf("%s", "Select an option\n\n");
        printf("%s", "(L)ist all books (titles only)\n");
        printf("%s", "(A)dd a new book\n");
        printf("%s", "(R)emove a book\n");
        printf("%s", "(U)pdate a book's details\n");
        printf("%s", "(V)iew a book's details\n");
        printf("%s", "(Q)uit\n");
        scanf("%49[^\n]s", buf);
        while (getchar() != '\n');
        if (strlen(buf) == 1)
        {
            switch (buf[0])
            {
            case 'L':
            case 'l':
                // List all books
                if (lib->bookCount > 0)
                {
                    printf("   Titles:\n");
                    for (int i = 0; i < lib->bookCount; i++)
                    {
                        printf("   %s\n", lib->inventory[i].title);
                    }
                }
                else
                    printf("%s", "The library has no books!\n");
                break;
            case 'A':
            case 'a':
                // Add a new book
                buf[0] = '\0';
                do
                {
                    printf("%s", "Title?\n");
                    scanf("%49[^\n]s", buf);
                    while (getchar() != '\n');
                }
                while (strlen(buf) <= 0 );
                strcpy(bk.title, buf);
                buf[0] = '\0';
                do
                {
                    printf("%s", "Author?\n");
                    scanf("%49[^\n]s", buf);
                    while (getchar() != '\n');
                }
                while (strlen(buf) <= 0 );
                strcpy(bk.author, buf);
                printf("%s", "Publication year?\n");
                do
                {
                    num = scanf("%d%c", &bk.pubYear, &term);
                    if (num != 2 || term != '\n')
                    {
                        printf("%s", "Please enter a valid year.\n");
                        while (getchar() != '\n');
                    }
                }
                while (num != 2 || term != '\n');
                lib->inventory[lib->bookCount] = bk;
                lib->bookCount++;
                saveLibrary(lib);
                break;
            case 'R':
            case 'r':
                // Remove a book
                if (lib->bookCount >= 1)
                {
                    printf("%s", "Select a book to remove\n\n");
                    for (int i = 0; i < lib->bookCount; i++)
                        printf("%d - %s\n", i + 1, lib->inventory[i].title);
                    scanf("%d", &input);
                    while (getchar() != '\n');
                    while (input <= 0 || input > lib->bookCount)
                    {
                        printf("%s", "Invalid entry. Try again.\n");
                        scanf("%d", &input);
                        while (getchar() != '\n');
                    }
                    printf("%s has been removed from the library.\n",
                           lib->inventory[input - 1].title);
                    removeBook(lib, input);
                    saveLibrary(lib);
                }
                //prints if user enters invalid input
                else
                {
                    printf("Why would you try to remove a book...\n");
                    printf("When you haven't even added any yet? -_-\n");
                }
                printf("%s", lib->inventory[0].title);
                break;
            case 'U':
            case 'u':
                // Update a book
                if (lib->bookCount >= 1)
                {
                    printf("%s", "Select a book to update\n\n");
                    for (int i = 0; i < lib->bookCount; i++)
                    {
                        printf("%d - %s\n", i + 1, lib->inventory[i].title);
                    }
                    scanf("%d", &input);
                    while (getchar() != '\n');
                    //input validation loop
                    while (input <= 0 || input > lib->bookCount)
                    {
                        printf("%s", "Invalid entry. Try again.\n");
                        scanf("%d", &input);
                        while (getchar() != '\n');
                    }
                    //do while loop if user enters wrong letter
                    do
                    {
                        printf("%s", "Which field would you like to update?\n\n");
                        printf("%s", "(T)itle\n");
                        printf("%s", "(A)uthor\n");
                        printf("%s", "(P)ublication Year\n");
                        scanf("%49[^\n]s", buf);
                        while (getchar() != '\n');
                        if (strlen(buf) == 1)
                        {
                            switch (buf[0])
                            {
                            case 'T':
                            case 't':
                                buf[0] = '\0';
                                //input validation loop
                                do
                                {
                                    printf("%s", "New title??\n");
                                    scanf("%49[^\n]s", buf);
                                    while (getchar() != '\n');
                                }
                                while (strlen(buf) <= 0 );
                                //puts new value into title variable
                                strcpy(lib->inventory[input - 1].title, buf);
                                saveLibrary(lib);
                                break;
                            case 'A':
                            case 'a':
                                buf[0] = '\0';
                                //input validation loop
                                do
                                {
                                    printf("%s", "New author??\n");
                                    scanf("%49[^\n]s", buf);
                                    while (getchar() != '\n');
                                }
                                while (strlen(buf) <= 0 );
                                //puts new value into author variable
                                strcpy(lib->inventory[input - 1].author, buf);
                                saveLibrary(lib);
                                break;
                            case 'P':
                            case 'p':
                                buf[0] = '\0';
                                //input validation loop for pubYear variable
                                do
                                {
                                    printf("%s", "New publication year?\n");
                                    num = scanf("%d%c",
                                                &lib->inventory[input - 1].pubYear,
                                                &term);
                                    if (num != 2 || term != '\n')
                                    {
                                        printf("%s",
                                               "Please enter a valid year.\n");
                                        while (getchar() != '\n');
                                    }
                                }
                                while (num != 2 || term != '\n');
                                saveLibrary(lib);
                                break;
                            default:
                                printf("%s", "Invalid entry. Try again.\n");
                            }
                        }
                        else
                            printf("%s", "Invalid entry. Try again.\n");
                    }
                    while (strlen(buf) == 1);
                }
                //message will show if user does not have any books in library
                else
                {
                    printf("There's no books in the library...\n");
                    printf("You should know that since you haven't added any >:|");
                }
                break;
            case 'V':
            case 'v':
                // View a book
                if (lib->bookCount >= 1)
                {
                    printf("%s", "Select a book to view details\n\n");
                    for (int i = 0; i < lib->bookCount; i++)
                        printf("%d - %s\n", i + 1, lib->inventory[i].title);
                    scanf("%d", &input);
                    while (getchar() != '\n');
                    //input validation if invalid input
                    while (input <= 0 || input > lib->bookCount)
                    {
                        printf("%s", "Invalid entry. Try again.\n");
                        scanf("%d", &input);
                        while (getchar() != '\n');
                    }
                    //stores variables into bk struct and displays
                    bk = getBook(lib, input);
                    printf("              Title: %s\n", bk.title);
                    printf("             Author: %s\n", bk.author);
                    printf("   Publication Year: %d\n", bk.pubYear);
                }
                //displays message if user has no books in library
                else
                {
                    printf("Trying to view books you haven't made?\n");
                    printf("I thought the users would be smarter than this.\n");
                }
                break;
            case 'Q':
            case 'q':
                running = false;
                break;
            default:
                printf("%s", "Invalid entry. Try again.\n");
            }
        }
        else
            printf("%s", "Invalid entry. Try again.\n");
    }
    // Bid the user farewell
    printf("%s", "Thank you for using this application. Goodbye.\n");
}
