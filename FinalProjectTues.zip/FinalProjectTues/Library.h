#ifndef LIBRARY_H_INCLUDED
#define LIBRARY_H_INCLUDED
#define MAX_SIZE 50
//structs used within files
typedef struct book
{
    char title[MAX_SIZE];
    char author[MAX_SIZE];
    int pubYear;
} book;

typedef struct library
{
    char name[MAX_SIZE];
    book inventory[MAX_SIZE];
    int bookCount;
} library;
//function prototypes
book getBook(library *lib, int index);
void removeBook(library *lib, int index);

#endif // LIBRARY_H_INCLUDED
