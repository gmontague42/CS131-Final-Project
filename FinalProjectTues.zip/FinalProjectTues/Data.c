#include <stdio.h>
#include <stdlib.h>
#include "Data.h"
#include "Library.h"
/**************************************************************
 * Function: loadLibrary
 * Description:  This function loads book titles and their
 *               details
 * Input: library *lib - main struct that holds all information
 * Output: Returns 0 if file load fails
 **************************************************************/
int loadLibrary(library *lib)
{
    FILE* fh = fopen(FILENAME, "r");
    if(fh == NULL)
    {
        printf("%s", "Cannot open file for reading. No books were loaded.\n");
        return 0; //test value for fail
    }
    else
    {
        fgets(lib->name, 50, fh);
        strtok(lib->name, "\n");
        fscanf(fh, "%d\n", &lib->bookCount);
        //loop through array of books and load everything to the array
        for (int i = 0; i < lib->bookCount; i++)
        {
            fgets(lib->inventory[i].title, 50, fh);
            strtok(lib->inventory[i].title, "\n");
            fgets(lib->inventory[i].author, 50, fh);
            strtok(lib->inventory[i].author, "\n");
            fscanf(fh, "%d\n", &lib->inventory[i].pubYear);
        }
        fclose(fh);
        return lib->bookCount;
    }
}
/**************************************************************
 * Function: saveLibrary
 * Description:  This function saves book details to a txt file
 * Input: library *lib - main struct that holds all information
 **************************************************************/
void saveLibrary(library *lib)
{
    FILE* fh = fopen(FILENAME, "w");
    if (fh == NULL)
        printf("%s", "Cannot open file for writing.\n");
    else
    {
        fprintf(fh, "%s\n", lib->name);
        fprintf(fh, "%d\n", lib->bookCount);
        //loop through array of books and save everything to file
        for (int i = 0; i < lib->bookCount; i++)
        {
            fprintf(fh, "%s\n", lib->inventory[i].title);
            fprintf(fh, "%s\n", lib->inventory[i].author);
            fprintf(fh, "%d\n", lib->inventory[i].pubYear);
        }
        printf("%s", "File save successful\n");
        fclose(fh);
    }
}
